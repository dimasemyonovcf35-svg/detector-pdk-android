# Контроль сигнала ПДК — Android prototype

This is an early test build, not a certified alarm or safety device.

## Build
The GitHub Actions workflow can build a debug APK with JDK 17 and Gradle 8.9.

## Important
- Android 8.0+ (API 26+), microphone permission required.
- Keep the persistent notification visible while monitoring.
- Disable battery optimization for this app on devices that aggressively stop background apps.
- Test at the actual speaker position and with all relevant operating conditions.
- Do not use this prototype as a replacement for certified gas detection or workplace alarm systems.
