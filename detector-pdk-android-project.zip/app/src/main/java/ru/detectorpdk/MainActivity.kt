package ru.detectorpdk

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var freqLabel: TextView
    private lateinit var levelLabel: TextView
    private var minFreq = 2000
    private var threshold = 65
    private var pendingAction = MonitorService.ACTION_START

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        minFreq = prefs.getInt("minFreq", 2000)
        threshold = prefs.getInt("threshold", 65)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
        }
        fun label(value: String, size: Float = 17f) = TextView(this).apply {
            text = value
            textSize = size
            setPadding(0, 9, 0, 9)
        }
        root.addView(label("Контроль сигнала ПДК", 24f))
        root.addView(label("Поставьте телефон рядом с колонкой. При обнаружении сигнала приложение включит сирену."))
        status = label("Статус: не запущено")
        root.addView(status)

        freqLabel = label("Минимальная частота: $minFreq Гц")
        root.addView(freqLabel)
        root.addView(SeekBar(this).apply {
            max = 4000
            progress = minFreq - 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    minFreq = 1000 + value
                    freqLabel.text = "Минимальная частота: $minFreq Гц"
                    prefs.edit().putInt("minFreq", minFreq).apply()
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        })

        levelLabel = label("Порог срабатывания: $threshold%")
        root.addView(levelLabel)
        root.addView(SeekBar(this).apply {
            max = 94
            progress = threshold - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    threshold = value + 1
                    levelLabel.text = "Порог срабатывания: $threshold%"
                    prefs.edit().putInt("threshold", threshold).apply()
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        })

        root.addView(label("После запуска сверните приложение — постоянное уведомление покажет, что прослушивание активно."))
        addButton(root, "Включить прослушивание") {
            pendingAction = MonitorService.ACTION_START
            requestPermissionsThenRun()
        }
        addButton(root, "Проверить сирену") {
            pendingAction = MonitorService.ACTION_TEST
            requestPermissionsThenRun()
        }
        addButton(root, "Выключить сирену") {
            send(MonitorService.ACTION_STOP_ALARM)
        }
        addButton(root, "Остановить прослушивание") {
            stopService(Intent(this, MonitorService::class.java))
            status.text = "Статус: не запущено"
        }
        setContentView(root)
    }

    private fun addButton(root: LinearLayout, title: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = title
            setOnClickListener { action() }
        })
    }

    private fun requestPermissionsThenRun() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 42) else runPending()
    }

    private fun runPending() {
        val intent = Intent(this, MonitorService::class.java).apply {
            action = pendingAction
            putExtra("minFreq", minFreq)
            putExtra("threshold", threshold)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            status.text = if (pendingAction == MonitorService.ACTION_START) "Статус: прослушивание включено" else "Статус: тест сирены"
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить службу: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun send(action: String) {
        startService(Intent(this, MonitorService::class.java).setAction(action))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 42 && results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) runPending()
        else Toast.makeText(this, "Разреши доступ к микрофону и уведомлениям", Toast.LENGTH_LONG).show()
    }
}
