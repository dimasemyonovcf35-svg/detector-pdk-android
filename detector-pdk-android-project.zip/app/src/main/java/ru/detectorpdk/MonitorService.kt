package ru.detectorpdk

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

class MonitorService : Service() {
    companion object {
        const val ACTION_START = "ru.detectorpdk.START"
        const val ACTION_TEST = "ru.detectorpdk.TEST"
        const val ACTION_STOP_ALARM = "ru.detectorpdk.STOP_ALARM"
        private const val CHANNEL = "pdk_monitor"
        private const val NOTIFICATION_ID = 41
    }

    @Volatile private var running = false
    @Volatile private var alarmOn = false
    private var minFreq = 2000
    private var threshold = 65
    private var recorder: AudioRecord? = null
    private var alarmTrack: AudioTrack? = null
    private var monitorThread: Thread? = null
    private var alarmThread: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastTrigger = 0L
    private var lastNotice = 0L

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Контроль ПДК", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> stopAlarm()
            ACTION_START -> {
                minFreq = intent.getIntExtra("minFreq", 2000)
                threshold = intent.getIntExtra("threshold", 65)
                startForeground(NOTIFICATION_ID, notification("Запуск прослушивания"))
                startMonitoring()
            }
            ACTION_TEST -> {
                startForeground(NOTIFICATION_ID, notification("Проверка сирены"))
                startAlarm()
            }
            else -> {
                startForeground(NOTIFICATION_ID, notification("Готово"))
            }
        }
        return START_STICKY
    }

    private fun startMonitoring() {
        if (running) return
        running = true
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DetectorPDK:Monitor").apply { acquire() }
        monitorThread = Thread {
            val rate = 44100
            val frame = 2048
            val minBuffer = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuffer <= 0) {
                updateNotification("Ошибка инициализации микрофона")
                running = false
                return@Thread
            }
            val audio = try {
                AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, max(minBuffer, frame * 4)).let {
                    if (it.state == AudioRecord.STATE_INITIALIZED) it
                    else {
                        it.release()
                        AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                            AudioFormat.ENCODING_PCM_16BIT, max(minBuffer, frame * 4))
                    }
                }
            } catch (_: Exception) {
                AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, max(minBuffer, frame * 4))
            }
            recorder = audio
            try {
                if (audio.state != AudioRecord.STATE_INITIALIZED) {
                    updateNotification("Микрофон не удалось запустить")
                    running = false
                    return@Thread
                }
                audio.startRecording()
                val samples = ShortArray(frame)
                val frequencies = (1000..5000 step 25).toList()
                val coeffs = frequencies.map { 2.0 * cos(2.0 * PI * it / rate) }.toDoubleArray()
                while (running) {
                    val count = audio.read(samples, 0, frame)
                    if (count == frame) {
                        val result = detect(samples, coeffs, frequencies, rate)
                        val now = System.currentTimeMillis()
                        val thresholdDb = -60.0 + (100 - threshold) * 0.4
                        if (result.second >= thresholdDb && result.first >= minFreq && now - lastTrigger > 3000) {
                            lastTrigger = now
                            updateNotification("Сигнал обнаружен: около ${result.first} Гц")
                            startAlarm()
                        } else if (!alarmOn && now - lastNotice > 1000) {
                            lastNotice = now
                            updateNotification("Слушаю · ${result.first} Гц · ${"%.0f".format(result.second)} dBFS")
                        }
                    }
                }
            } catch (_: SecurityException) {
                updateNotification("Нет разрешения на микрофон")
            } catch (_: Exception) {
                updateNotification("Ошибка чтения микрофона")
            } finally {
                try { audio.stop() } catch (_: Exception) {}
                audio.release()
                recorder = null
            }
        }.also { it.name = "PDK-Monitor"; it.start() }
    }

    // Goertzel magnitude estimate at 25 Hz steps; returns dominant frequency and level in dBFS.
    private fun detect(x: ShortArray, coeffs: DoubleArray, frequencies: List<Int>, rate: Int): Pair<Int, Double> {
        var bestFrequency = 0
        var bestAmplitude = 0.0
        val n = x.size
        for (k in frequencies.indices) {
            val coeff = coeffs[k]
            var q1 = 0.0
            var q2 = 0.0
            for (i in 0 until n) {
                val sample = (x[i] / 32768.0) * (0.5 - 0.5 * cos(2.0 * PI * i / (n - 1)))
                val q0 = sample + coeff * q1 - q2
                q2 = q1
                q1 = q0
            }
            val power = max(0.0, q1 * q1 + q2 * q2 - coeff * q1 * q2)
            val amplitude = 2.0 * sqrt(power) / n
            if (amplitude > bestAmplitude) {
                bestAmplitude = amplitude
                bestFrequency = frequencies[k]
            }
        }
        val db = if (bestAmplitude <= 1e-9) -120.0 else 20.0 * ln(bestAmplitude) / ln(10.0)
        return Pair(bestFrequency, db)
    }

    private fun startAlarm() {
        if (alarmOn) return
        alarmOn = true
        alarmThread = Thread {
            val rate = 44100
            val data = ShortArray(2048)
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(max(min, data.size * 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            alarmTrack = track
            try {
                track.play()
                var phase = 0.0
                var high = true
                while (alarmOn) {
                    val frequency = if (high) 2100.0 else 1350.0
                    for (i in data.indices) {
                        data[i] = (sin(phase) * 25000).toInt().toShort()
                        phase += 2.0 * PI * frequency / rate
                        if (phase >= 2.0 * PI) phase -= 2.0 * PI
                    }
                    track.write(data, 0, data.size)
                    high = !high
                }
            } catch (_: Exception) {
            } finally {
                try { track.stop() } catch (_: Exception) {}
                track.release()
                alarmTrack = null
            }
        }.also { it.name = "PDK-Alarm"; it.start() }
    }

    private fun stopAlarm() {
        alarmOn = false
        try { alarmTrack?.pause(); alarmTrack?.flush() } catch (_: Exception) {}
        updateNotification(if (running) "Прослушивание активно" else "Сирена выключена")
    }

    private fun notification(message: String): Notification =
        Notification.Builder(this, CHANNEL)
            .setContentTitle("Контроль сигнала ПДК")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setOngoing(true)
            .build()

    private fun updateNotification(message: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, notification(message))
    }

    override fun onDestroy() {
        running = false
        stopAlarm()
        try { recorder?.stop() } catch (_: Exception) {}
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
